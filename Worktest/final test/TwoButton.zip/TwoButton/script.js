let i = 0;

const plus = () => {
	i++;
	console.log(i);
}

const minus = () => {
	i--;
	console.log(i);
}