import React from "react";

function Form(props) {

  return ( <div>
		<p>Переданная дочь</p>
		{props.children}
	</div>

  );
}

export default Form;
