import React from "react";

function Header(props) {
  const { url, nameImg, name } = props;
  return (
    <div>
      <p>Автор: {name} Картина: <a href={url}>{nameImg}</a></p>
    </div>
  );
}

export default Header;
