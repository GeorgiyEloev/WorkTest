import React, { useState } from "react";
import { Switch, Route, Redirect, useHistory } from "react-router-dom";
import Header from "./components/Header";
import ButtonOne from "./components/ButtonOne";
import ButtonTwo from "./components/ButtonTwo";
import "./App.scss";

function App() {
  const [name, setName] = useState("НАЖМИ НА ПРАВЕЛЬНУЮ КНОПКУ");

  let history = useHistory();

  return (
    <div className="App">
      <Header url="https://icdn.lenta.ru/images/2021/04/27/16/20210427163138131/square_320_c09ebae17387b7d6eeb9fa0d42afe5ee.jpg" nameImg="кот" name="Наташа" />
      <Header url="https://s.poembook.ru/theme/a5/8c/e8/f5bdd1aafd0d95b5d73301fcec8f882208e50bbc.jpeg" nameImg="я не пью" name="Тамик" />
      <Header url="https://upload.wikimedia.org/wikipedia/commons/3/3e/Weizenbier.jpg" nameImg="пиво" name="Вова" />
    </div>
  );
}

export default App;
