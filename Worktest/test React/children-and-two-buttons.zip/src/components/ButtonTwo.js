import React from "react";

function ButtonOne({ setName }) {
  return (
    <button
      onClick={() => {
        setName("ЯМЭТЭ КУДАСАЙ!!!!");
      }}
    >
      КНОПКА ДВА
    </button>
  );
}

export default ButtonOne;
