import React from "react";

function ButtonOne({ setName }) {
  return (
    <button
      onClick={() => {
        setName("ТЫ НАЖАЛА НА МЕНЯ ЗАЧЕМ!!!!!!! МНЕ БОЛЬНО(((");
      }}
    >
      КНОПКА ОДИН
    </button>
  );
}

export default ButtonOne;
