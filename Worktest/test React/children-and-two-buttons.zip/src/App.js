import React, { useState } from "react";
import ButtonOne from "./components/ButtonOne";
import ButtonTwo from "./components/ButtonTwo"
import "./App.scss";

function App() {
  const [name, setName] = useState("НАЖМИ НА ПРАВЕЛЬНУЮ КНОПКУ");

  return (
    <div className="App">
      <header>{name}</header>
      <div style={{ display: "flex" }}>
        <ButtonOne setName={setName} />
				<ButtonTwo setName={setName} />
      </div>
    </div>
  );
}

export default App;
