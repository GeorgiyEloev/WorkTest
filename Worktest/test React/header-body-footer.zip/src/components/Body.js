import React from "react";
import "./Body.scss";

function Body() {
  return <div className="mainBody">
		<h2>Я тут Подумал это важная информация наверное</h2>
		<p>Тамик не пьет от слова совсем</p>
	</div>;
}

export default Body;
