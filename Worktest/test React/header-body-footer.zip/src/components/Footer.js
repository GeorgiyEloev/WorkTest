import React from "react";
import "./Footer.scss";

function Footer() {
  return (
    <div>
      <img className="imgRet" src="https://s.poembook.ru/theme/a5/8c/e8/f5bdd1aafd0d95b5d73301fcec8f882208e50bbc.jpeg" />
    </div>
  );
}

export default Footer;
