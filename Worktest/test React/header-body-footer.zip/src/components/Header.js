import React from "react";
import "./Header.scss";

function Header(props) {
  const { name } = props;
  return (
    <div className="main">
      <h1>
        Привет {name}!? Это же ты
        &#128064;&#128064;&#128064;&#128064;&#128064;&#128064;&#128064;&#128064;&#128064;???
      </h1>
      <div className="main-button">
        <button onClick={() => alert("Ну, я поверю")}>Да</button>
        <button onClick={() => alert("а кто тогда??")}>Нет</button>
      </div>
    </div>
  );
}

export default Header;
