import React, { useState } from "react";
import { Switch, Route, Redirect, useHistory } from "react-router-dom";
import Body from "./components/Body";
import Header from "./components/Header";
import Footer from "./components/Footer";
import "./App.scss";

function App() {
  const [name, setName] = useState("НАЖМИ НА ПРАВЕЛЬНУЮ КНОПКУ");

  let history = useHistory();

  return (
    <div className="App">
      <Header name="Nataly"/>
      <Body />
      <Footer />
    </div>
  );
}

export default App;
