import React, { useState } from "react";
import { Switch, Route, Redirect, useHistory } from "react-router-dom";
import ButtonOne from "./components/ButtonOne";
import ButtonTwo from "./components/ButtonTwo";
import "./App.scss";

function App() {
  const [name, setName] = useState("НАЖМИ НА ПРАВЕЛЬНУЮ КНОПКУ");

	let history = useHistory();

  return (
    <div className="App">
      <header>{name}</header>
      <div style={{ display: "flex" }}>
        <button onClick={() => history.push("/one")}>1</button>
        <button onClick={() => history.push("/two")}>2</button>
      </div>
      <Switch>
        <Route path="/one">
          <ButtonOne />
        </Route>
        <Route path="/two">
          <ButtonTwo />
        </Route>
        <Redirect from="" to="" />
      </Switch>
    </div>
  );
}

export default App;
