import React from "react";

function ButtonOne() {
  return <p>ТЫ НАЖАЛА НА МЕНЯ ЗАЧЕМ!!!!!!! МНЕ БОЛЬНО(((</p>;
}

export default ButtonOne;
