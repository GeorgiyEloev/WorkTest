import React from "react";

function ButtonOne() {
  return <p>А ТУТ БОЛЬШЕ НЕ ЯМЭТЭ КУДАСАЙ!!!! ХЭХЭ</p>;
}

export default ButtonOne;
