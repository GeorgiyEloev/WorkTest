import React, { useState } from "react";
import { Switch, Route, Redirect, useHistory } from "react-router-dom";
import Form from "./components/Form";
import ButtonOne from "./components/ButtonOne";
import ButtonTwo from "./components/ButtonTwo";
import "./App.scss";

function App() {
  const [name, setName] = useState("НАЖМИ НА ПРАВЕЛЬНУЮ КНОПКУ");

	let history = useHistory();

  return (
    <div className="App">
			<Form />
    </div>
  );
}

export default App;
