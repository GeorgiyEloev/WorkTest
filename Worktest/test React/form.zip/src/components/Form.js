import React from "react";

function Form() {
  const consoleLog = (e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    console.log(data.get("name1"));
    console.log(data.get("name2"));
  };
  return (
    <form onSubmit={consoleLog}>
      <input type="text" name="name1" />
      <input type="text" name="name2" />
      <button>console.log</button>
    </form>
  );
}

export default Form;
